<?php include 'includes/session.php'; ?>
<?php include 'includes/header.php'; ?>
<body class="hold-transition skin-blue layout-top-nav">
<div class="wrapper">

	<?php include 'includes/navbar.php'; ?>
	 
	  <div class="content-wrapper">
	    <div class="container">

	      <!-- Main content -->
	      <section class="content">
	        <div class="row">
	        	<div class="col-sm-12">
	        		<?php
	        			if(isset($_SESSION['error'])){
	        				echo "
	        					<div class='alert alert-danger'>
	        						".$_SESSION['error']."
	        					</div>
	        				";
	        				unset($_SESSION['error']);
	        			}
	        		?>
	        		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
		                <ol class="carousel-indicators">
		                  <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
		                  <li data-target="#carousel-example-generic" data-slide-to="1" class=""></li>
		                  <li data-target="#carousel-example-generic" data-slide-to="2" class=""></li>
		                </ol>
		                <div class="carousel-inner">
		                  <div class="item active">
		                    <img src="images/banner3.jpg" alt="First slide" height="100%" width="100%">
		                  </div>
		                  <div class="item">
		                    <img src="images/banner2.jpg" alt="Second slide" height="100%" width="100%">
		                  </div>
		                  <div class="item">
		                    <img src="images/banner1.jpg" alt="Third slide" height="100%" width="100%">
		                  </div>
		                </div>
		                <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
		                  <span class="fa fa-angle-left"></span>
		                </a>
		                <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
		                  <span class="fa fa-angle-right"></span>
		                </a>
		            </div>

		       	
	        	</div>
	        	
	        </div>
	      </section>

<section class="l-section-spacing text-center" role="main" > 
  <div class="row">  

<div class="medium-6 columns m-promotion">
<h2 class="m-promotion-title">Looking for an event planner?</h2>
<h4>Find any service fast & easy</h4>
<p class="m-promotion-description">Whether you're organizing a corporate event or a private party, Eventers has a wide selection of amazing event spaces with pictures and all the information you need. Use the search function to organize the perfect event for you. In addition to regular settings, we have many features to make your day truly unique!</p>
<a class="button success" href="#">Browse Services</a>
</div>

<div class="medium-6 columns m-promotion">
<h2 class="m-promotion-title">You own a service?</h2>
<h4>Get more bookings through us</h4>
<p class="m-promotion-description">We can make sure that customers come to you! Do you have a banquet hall, catering service or photographer that could get more bookings? Add your service on Eventers and we will help you find new customers with no monthly or annual fees.</p>

</div>

</section>
	     
	    </div>
	  </div>
  
  	<?php include 'includes/footer.php'; ?>
</div>

<?php include 'includes/scripts.php'; ?>
</body>
</html>