

//smooth scroll

$(function(){
	$("a.smooth-scroll").click(function(event){
		event.preventDefault();

//get or return id like #about ,#faculty
		var section = $(this).attr("href");
		$("html , body").animate({
           scrollTop: $(section).offset().top
		},1250);
	});
});


/********************************
         date picker

********************************/
$(document).ready(function(){
		var date_input=$('input[name="date"]'); //our date input has the name "date"
		var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
		date_input.datepicker({
			format: 'mm/dd/yyyy',
			container: container,
			todayHighlight: true,
			autoclose: true,
		})
	})

